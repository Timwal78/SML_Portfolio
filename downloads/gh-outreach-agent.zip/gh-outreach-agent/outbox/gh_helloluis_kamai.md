---
id: gh_helloluis_kamai
to_guess: https://www.cryptoday.live
repo: helloluis/kamai
owner: helloluis
stars: 0
status: drafted
subject: quick question about kamai
---

# Send checklist
- [ ] Find real email (GitHub profile / commit / site) if to_guess empty
- [ ] Personalize one line if needed
- [ ] Send manually (or SMTP when configured)
- [ ] `python3 -m gho mark-sent --id gh_helloluis_kamai`

## Subject
quick question about kamai

## Body
Hi Luis,

I found helloluis/kamai on GitHub (Agentic headless browsing service with x402 payments on Celo), so honest question: are your APIs actually visible to AI agents — or only to humans reading the README?

Most tool APIs stay invisible to agents. Docs and OpenAPI don't get you ranked.

Two pieces we built:

1) IMP (free, open-source) — ranking rules so capabilities can be compared fairly
   https://github.com/Timwal78/intention-market-protocol

2) AMB (live beacons) — each API broadcasts what it does, price, rails, and quality
   so agents can find and pick winners (this is the visibility layer)

We host the live index so you don't operate it:
• Match API (ranked capabilities)
• API keys + metering
• Starter $49/mo · Pro $199/mo

Protocol free. Hosted Premium Index paid.
https://www.scriptmasterlabs.com/pricing.html

Docs: https://mcp-x402.onrender.com/v1

Curious either way — reply stop and I won't follow up.

Tim
Script Master Labs, LLC (SDVOSB) · Kinston, NC 28504
321-261-8620

