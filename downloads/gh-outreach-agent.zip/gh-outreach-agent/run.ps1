# SML GitHub outreach helper (Windows PowerShell)
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  Write-Host "Python not found. Install from https://www.python.org/downloads/ and re-open PowerShell."
  exit 1
}

Write-Host "Working dir: $Root"
if ($env:GH_TOKEN) { Write-Host "GH_TOKEN is set" } else { Write-Host "GH_TOKEN not set (optional; lower rate limits)" }

python -m gho stats
python -m gho scout --limit 15
python -m gho draft --limit 5
python -m gho stats
Write-Host ""
Write-Host "Drafts in: $Root\outbox"
Get-ChildItem outbox -Filter *.md | Select-Object -ExpandProperty Name
