# GitHub Ads / Bidding Agent — Runbook

## What hit you

**From:** Forkfolio `<forkfolioteam@forkfolio.dev>`  
**Subject:** `quick question about SML_Portfolio`  
**Pattern:** Scrape public GitHub → personalize repo name → SendGrid CTA → waitlist  

They sell: auto portfolio + chat bot.  
**We sell:** Hosted Premium Index $49 (AMB visibility + IMP ranking + Match API).

## Our agent (built)

Path: `gh-outreach-agent/`

| Command | Does |
|---|---|
| `python3 -m gho scout` | GitHub search → `data/leads.jsonl` |
| `python3 -m gho draft` | Write `outbox/*.md` paste-ready emails |
| `python3 -m gho list` / `stats` | Inventory |
| `python3 -m gho mark-sent --id …` | After you send manually |

**Default = human-in-the-loop.** No auto-blast (avoids spam bans / GitHub ToS hell).

## Message spine (every draft)

1. Found **their repo** (proof you looked)  
2. Question: are APIs **visible to agents**?  
3. **IMP** free ranking rules  
4. **AMB** live beacons = visibility  
5. **Hosted $49** Match API  
6. Link: pricing.html  
7. Reply stop  

## “Bidding” on GitHub (what that means for us)

| Channel | Action |
|---|---|
| **Cold email** (Forkfolio-style) | scout → draft → you send |
| **GitHub topics/search presence** | keep IMP + portfolio topics: `x402`, `ai-agents`, `mcp`, `amb` |
| **Issue/PR soft touch** | only where relevant — not spam |
| **Sponsored** | later (GitHub Sponsors ads / external) — not v0 |
| **x402scan / agent registries** | keep mcp AMB hot so *inbound* bots find you |

v0 = **outbound discovery + drafts**. Auto-SMTP / multi-step sequences = v1 after first $49.

## Ops cadence (15 min/day)

1. `scout --limit 15`  
2. `draft --limit 5`  
3. Open 5 outbox files → find email → send  
4. `mark-sent`  
5. Track: drafts → sends → checkout sessions → paid  

## Do not

- Auto-email thousands  
- Impersonate GitHub staff  
- Promise FedRAMP  
- Advertise dead hosts (only mcp + restored keepers)  
- New Render service for this agent  

## Env

```bash
export GH_TOKEN=...   # optional; higher rate limits
export GHO_DATA_DIR=./data
```
