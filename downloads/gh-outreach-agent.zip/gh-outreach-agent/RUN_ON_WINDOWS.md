# Run on Windows (PowerShell)

This folder was built on the **Hermes Linux agent host**.
It is NOT under `C:\Users\timot\.hermes\` unless you copy it there.

## 1) Copy this folder to your PC
Example:
  C:\Users\timot\Downloads\gh-outreach-agent

## 2) Install Python 3 (if needed)
https://www.python.org/downloads/
Check "Add python.exe to PATH"
Then in a NEW PowerShell:

  python --version

## 3) PowerShell commands (not bash)

  cd $env:USERPROFILE\Downloads\gh-outreach-agent
  $env:GH_TOKEN = "ghp_your_token_here"   # optional
  python -m gho scout --limit 15
  python -m gho draft --limit 5
  python -m gho stats
  dir outbox

## 4) Or just send the drafts already in outbox\
Open each .md file → copy Subject + Body → send from Gmail.

## Notes
- `export` is bash-only. In PowerShell use `$env:NAME = "value"`.
- Prefer `python` not `python3` on Windows Store setups.
- Default is human send (no auto-email blast).
