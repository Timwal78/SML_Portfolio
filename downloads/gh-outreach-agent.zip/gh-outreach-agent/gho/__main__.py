"""GitHub Outreach Agent — scout builders, draft $49 Premium Index pitches."""
from __future__ import annotations

import argparse
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get("GHO_DATA_DIR", ROOT / "data"))
OUTBOX = Path(os.environ.get("GHO_OUTBOX_DIR", ROOT / "outbox"))
LEADS_FILE = DATA / "leads.jsonl"
SENT_FILE = DATA / "sent.jsonl"

PRICING = "https://www.scriptmasterlabs.com/pricing.html"
OSS = "https://github.com/Timwal78/intention-market-protocol"
MATCH = "https://mcp-x402.onrender.com/v1"
PHONE = "321-261-8620"
NAP = "Script Master Labs, LLC (SDVOSB) · Kinston, NC 28504"

DEFAULT_QUERIES = [
    "x402 language:TypeScript",
    "x402 language:Python",
    "topic:mcp topic:ai-agents",
    'agent wallet OR agent payments in:readme',
    "openai agents sdk OR langgraph tools in:readme",
    "modelcontextprotocol in:readme",
]


@dataclass
class Lead:
    id: str
    source: str
    repo_full_name: str
    repo_url: str
    owner_login: str
    owner_html: str
    description: str = ""
    stars: int = 0
    language: str = ""
    topics: list[str] = field(default_factory=list)
    email: str | None = None
    name: str | None = None
    blog: str | None = None
    twitter: str | None = None
    discovered_at: str = ""
    status: str = "new"  # new | drafted | sent | skipped
    notes: str = ""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure_dirs() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    OUTBOX.mkdir(parents=True, exist_ok=True)


def _gh_headers() -> dict[str, str]:
    h = {
        "User-Agent": "sml-gh-outreach-agent/0.1",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    tok = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN") or ""
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def _gh_get(url: str, timeout: int = 30) -> tuple[int, Any]:
    req = urllib.request.Request(url, headers=_gh_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, {"message": body[:300]}
    except Exception as e:
        return 0, {"message": str(e)}


def _append_jsonl(path: Path, obj: dict) -> None:
    _ensure_dirs()
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def _lead_id(full_name: str) -> str:
    return "gh_" + re.sub(r"[^a-zA-Z0-9_-]+", "_", full_name.lower())[:80]


def search_repos(query: str, per_page: int = 20, page: int = 1) -> list[dict]:
    q = urllib.parse.quote(query)
    url = (
        f"https://api.github.com/search/repositories?q={q}"
        f"&sort=updated&order=desc&per_page={per_page}&page={page}"
    )
    st, data = _gh_get(url)
    if st != 200:
        raise RuntimeError(f"GitHub search {st}: {data}")
    return list(data.get("items") or [])


def fetch_user(login: str) -> dict:
    st, data = _gh_get(f"https://api.github.com/users/{urllib.parse.quote(login)}")
    if st != 200:
        return {}
    return data if isinstance(data, dict) else {}


def scout(
    queries: list[str] | None = None,
    limit: int = 20,
    sleep_s: float = 2.0,
    skip_self: bool = True,
) -> list[Lead]:
    """Discover repos/owners matching agent/x402/MCP signals."""
    _ensure_dirs()
    queries = queries or DEFAULT_QUERIES
    existing = {r.get("id") for r in _load_jsonl(LEADS_FILE)}
    found: list[Lead] = []
    per_q = max(5, min(30, limit))

    for qi, q in enumerate(queries):
        if len(found) >= limit:
            break
        try:
            items = search_repos(q, per_page=per_q)
        except Exception as e:
            print(f"[scout] query fail {q!r}: {e}")
            continue
        print(f"[scout] {q!r} -> {len(items)} repos")
        for item in items:
            if len(found) >= limit:
                break
            full = item.get("full_name") or ""
            owner = (item.get("owner") or {}).get("login") or full.split("/")[0]
            if skip_self and owner.lower() in {"timwal78", "scriptmasterlabs"}:
                continue
            lid = _lead_id(full)
            if lid in existing or any(x.id == lid for x in found):
                continue
            user = fetch_user(owner)
            time.sleep(sleep_s)  # be polite
            lead = Lead(
                id=lid,
                source=f"search:{q[:60]}",
                repo_full_name=full,
                repo_url=item.get("html_url") or f"https://github.com/{full}",
                owner_login=owner,
                owner_html=user.get("html_url") or f"https://github.com/{owner}",
                description=(item.get("description") or "")[:300],
                stars=int(item.get("stargazers_count") or 0),
                language=item.get("language") or "",
                topics=list(item.get("topics") or [])[:12],
                email=user.get("email"),
                name=user.get("name"),
                blog=user.get("blog") or None,
                twitter=user.get("twitter_username"),
                discovered_at=_now(),
                status="new",
            )
            found.append(lead)
            _append_jsonl(LEADS_FILE, asdict(lead))
            existing.add(lid)
        time.sleep(sleep_s)
    print(f"[scout] wrote {len(found)} new leads -> {LEADS_FILE}")
    return found


def _first_name(lead: dict) -> str:
    name = (lead.get("name") or "").strip()
    if name:
        return name.split()[0]
    login = lead.get("owner_login") or "there"
    return login


def draft_email(lead: dict) -> dict[str, str]:
    """Forkfolio-style personalization → SML $49 offer."""
    who = _first_name(lead)
    repo = lead.get("repo_full_name") or "your repo"
    desc = (lead.get("description") or "").strip()
    hook = desc if desc else "the agent/tooling work"
    if len(hook) > 120:
        hook = hook[:117] + "..."

    subject = f"quick question about {repo.split('/')[-1]}"

    body = f"""Hi {who},

I found {repo} on GitHub ({hook}), so honest question: are your APIs actually visible to AI agents — or only to humans reading the README?

Most tool APIs stay invisible to agents. Docs and OpenAPI don't get you ranked.

Two pieces we built:

1) IMP (free, open-source) — ranking rules so capabilities can be compared fairly
   {OSS}

2) AMB (live beacons) — each API broadcasts what it does, price, rails, and quality
   so agents can find and pick winners (this is the visibility layer)

We host the live index so you don't operate it:
• Match API (ranked capabilities)
• API keys + metering
• Starter $49/mo · Pro $199/mo

Protocol free. Hosted Premium Index paid.
{PRICING}

Docs: {MATCH}

Curious either way — reply stop and I won't follow up.

Tim
{NAP}
{PHONE}
"""
    return {"subject": subject, "body": body.strip() + "\n"}


def draft_batch(limit: int = 10, only_with_email: bool = False) -> list[Path]:
    _ensure_dirs()
    leads = _load_jsonl(LEADS_FILE)
    # newest first
    leads = list(reversed(leads))
    written: list[Path] = []
    n = 0
    for lead in leads:
        if n >= limit:
            break
        if lead.get("status") not in (None, "new", "drafted"):
            continue
        if only_with_email and not lead.get("email"):
            continue
        # skip if outbox exists
        path = OUTBOX / f"{lead['id']}.md"
        mail = draft_email(lead)
        contact = lead.get("email") or lead.get("blog") or lead.get("owner_html")
        md = f"""---
id: {lead.get('id')}
to_guess: {contact}
repo: {lead.get('repo_full_name')}
owner: {lead.get('owner_login')}
stars: {lead.get('stars')}
status: drafted
subject: {mail['subject']}
---

# Send checklist
- [ ] Find real email (GitHub profile / commit / site) if to_guess empty
- [ ] Personalize one line if needed
- [ ] Send manually (or SMTP when configured)
- [ ] `python3 -m gho mark-sent --id {lead.get('id')}`

## Subject
{mail['subject']}

## Body
{mail['body']}
"""
        path.write_text(md, encoding="utf-8")
        written.append(path)
        # update status in a side status file (jsonl is append-only; write status overlay)
        _append_jsonl(DATA / "status.jsonl", {"id": lead["id"], "status": "drafted", "at": _now()})
        n += 1
    print(f"[draft] {len(written)} drafts -> {OUTBOX}")
    return written


def list_leads(limit: int = 30) -> None:
    leads = list(reversed(_load_jsonl(LEADS_FILE)))[:limit]
    print(f"{'id':40} {'repo':40} {'email':28} stars")
    for L in leads:
        print(
            f"{(L.get('id') or '')[:40]:40} "
            f"{(L.get('repo_full_name') or '')[:40]:40} "
            f"{(L.get('email') or '-')[:28]:28} "
            f"{L.get('stars')}"
        )


def mark_sent(lead_id: str) -> None:
    _append_jsonl(
        SENT_FILE,
        {"id": lead_id, "sent_at": _now(), "product": "premium-index-49"},
    )
    _append_jsonl(DATA / "status.jsonl", {"id": lead_id, "status": "sent", "at": _now()})
    print(f"[sent] {lead_id}")


def stats() -> None:
    leads = _load_jsonl(LEADS_FILE)
    sent = _load_jsonl(SENT_FILE)
    drafts = list(OUTBOX.glob("*.md")) if OUTBOX.exists() else []
    with_email = sum(1 for L in leads if L.get("email"))
    print(
        json.dumps(
            {
                "leads": len(leads),
                "with_public_email": with_email,
                "drafts": len(drafts),
                "sent": len(sent),
                "pricing": PRICING,
            },
            indent=2,
        )
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="gho", description="SML GitHub outreach agent")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scout", help="Search GitHub for targets")
    s.add_argument("--query", action="append", dest="queries", help="Extra search query (repeatable)")
    s.add_argument("--limit", type=int, default=20)
    s.add_argument("--sleep", type=float, default=2.0)

    d = sub.add_parser("draft", help="Write outbox email drafts")
    d.add_argument("--limit", type=int, default=10)
    d.add_argument("--email-only", action="store_true")

    sub.add_parser("list", help="List leads")
    sub.add_parser("stats", help="Counts")

    m = sub.add_parser("mark-sent", help="Record manual send")
    m.add_argument("--id", required=True)

    a = sub.add_parser("show-template", help="Print base email template")
    a.add_argument("--repo", default="owner/demo-agent-tools")

    args = p.parse_args(argv)

    if args.cmd == "scout":
        scout(queries=args.queries or None, limit=args.limit, sleep_s=args.sleep)
    elif args.cmd == "draft":
        draft_batch(limit=args.limit, only_with_email=args.email_only)
    elif args.cmd == "list":
        list_leads()
    elif args.cmd == "stats":
        stats()
    elif args.cmd == "mark-sent":
        mark_sent(args.id)
    elif args.cmd == "show-template":
        mail = draft_email(
            {
                "name": "Alex",
                "repo_full_name": args.repo,
                "description": "agent tools and MCP servers",
                "owner_login": args.repo.split("/")[0],
            }
        )
        print("SUBJECT:", mail["subject"])
        print(mail["body"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
