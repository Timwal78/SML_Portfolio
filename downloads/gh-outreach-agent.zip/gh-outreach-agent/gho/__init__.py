"""SML GitHub Outreach Agent package."""
__version__ = "0.1.0"
