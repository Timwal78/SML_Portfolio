# GitHub Outreach Agent (SML)

**Job:** Find builders on GitHub (same pattern as Forkfolio → you),  
personalize a short pitch, queue for **human send** (or later SMTP).

**Sell:** Hosted Premium Index — **$49/mo**  
**Story:** AMB (agent visibility) + IMP (open ranking) + hosted Match API  
**Not:** Free AMB doctrine. IMP free footnote only.

## Why this exists

You got cold email from `forkfolioteam@forkfolio.dev`:
- Subject: `quick question about SML_Portfolio`
- Found via GitHub → SendGrid tracked links → waitlist CTA

That works. We run the **same funnel** for Script Master Labs.

## Safety (hard rules)

1. **Queue first** — default is draft files, not auto-send  
2. **Rate limits** — GitHub search ≤ 10 req/min unauthenticated; with token better  
3. **No bought lists** — only public GitHub signals  
4. **One product** — $49 Premium Index (+ pricing link)  
5. **No Render Starter** — runs local / cron on existing machine  
6. **Unsubscribe / stop** — include reply-stop line  

## Quick start

```bash
cd gh-outreach-agent
export GH_TOKEN=ghp_...   # optional but recommended
python3 -m gho scout --query 'x402 OR "ai agent" OR mcp topic:ai-agents' --limit 20
python3 -m gho draft --limit 10
python3 -m gho list
# Review outbox/*.md then:
python3 -m gho mark-sent --id <id>   # after you manually send
```

## Output

- `data/leads.jsonl` — discovered targets  
- `outbox/*.md` — paste-ready emails  
- `data/sent.jsonl` — audit log  

## Pricing CTA (always)

https://www.scriptmasterlabs.com/pricing.html
