"""Billing multi-rail + ads + pricing card tests."""

from __future__ import annotations

import os
import uuid

os.environ["SWARM_MM_DEV_OPEN"] = "1"
os.environ.pop("SML_API_KEY", None)

from fastapi.testclient import TestClient

from swarm_mm.api.app import app
from swarm_mm.billing.rails import build_accepts, rails_public
from swarm_mm.billing.x402 import x402_challenge
from swarm_mm.marketing.beastmode import full_pack, x_posts

client = TestClient(app)


def test_rails_include_usdc_sol_usdg():
    rails = rails_public()
    symbols = {r["symbol"] for r in rails["rails"]}
    assert "USDC" in symbols
    assert "USDG" in symbols
    accepts = build_accepts(19.0, "/v1/billing/subscribe/signal")
    nets = {a["network"] for a in accepts}
    assert any(n.startswith("eip155:8453") for n in nets)
    assert any(n.startswith("eip155:4663") for n in nets)
    assert any(n.startswith("solana:") for n in nets)


def test_x402_challenge_multi_rail_amount():
    ch = x402_challenge(0.001, "/v1/signal/levels")
    assert ch["x402Version"] == 1
    assert len(ch["accepts"]) >= 3
    # 0.001 * 1e6 = 1000
    assert ch["accepts"][0]["maxAmountRequired"] == "1000"
    assert "USDC" in ch["settle_in"] or "USDG" in ch["settle_in"]


def test_pricing_card_has_mechanism_free_monthly_ppc():
    r = client.get("/v1/pricing")
    assert r.status_code == 200
    d = r.json()
    assert "mechanism" in d
    assert d["free"]["price_usd"] == 0
    months = {m["plan"]: m["usd"] for m in d["monthly"]}
    assert months["signal"] == 19.0
    assert months["sim_premium"] == 9.0
    assert months["b2b"] == 5000.0
    tools = {t["tool"]: t["usd"] for t in d["agent_pay_per_call"]["tools"]}
    assert tools["signal_swarm.levels"] == 0.001
    assert "crypto_rails" in d


def test_subscribe_free_and_paid_402():
    uid = f"bill_{uuid.uuid4().hex[:8]}"
    r = client.post(f"/v1/billing/subscribe/sim_free?user_id={uid}")
    assert r.status_code == 200
    assert r.json()["subscription"]["plan"] == "sim_free"

    # paid without proof → 402 multi-rail
    r2 = client.post(f"/v1/billing/subscribe/signal?user_id={uid}")
    assert r2.status_code == 402
    body = r2.json()
    assert body["price_usd"] == 19.0
    assert len(body["accepts"]) >= 3

    # soft proof activates
    r3 = client.post(
        f"/v1/billing/subscribe/signal?user_id={uid}&rail=base_usdc",
        headers={"X-PAYMENT": "0x" + "ab" * 32},
    )
    assert r3.status_code == 200
    assert r3.json()["subscription"]["status"] == "active"
    assert r3.json()["subscription"]["price_usd_mo"] == 19.0


def test_ads_pack_explains_mechanism_and_prices():
    r = client.get("/v1/ads/beastmode")
    assert r.status_code == 200
    d = r.json()
    assert "coordination" in d["mechanism"]["one_liner"].lower() or "swarm" in d["mechanism"]["one_liner"].lower()
    assert d["free"]["price"] == 0
    assert any(p["usd"] == 19.0 for p in d["prices"]["monthly"])
    posts = x_posts()
    assert len(posts) >= 4
    # cashtag rule: max one $ token (e.g. $USDC); prices spelled without $
    for p in posts:
        assert p.count("$") <= 1, p


def test_landing_and_well_known():
    assert client.get("/landing").status_code == 200
    wk = client.get("/.well-known/x402").json()
    assert wk["agent_pay_per_call"] is True
    assert "monthly_crypto" in wk
    tiers = {x.get("tier") for x in wk["resources"]}
    assert "free" in tiers and "ppc" in tiers and "monthly" in tiers


def test_ads_x_endpoint():
    r = client.get("/v1/ads/x")
    assert r.status_code == 200
    assert len(r.json()["posts"]) >= 3
