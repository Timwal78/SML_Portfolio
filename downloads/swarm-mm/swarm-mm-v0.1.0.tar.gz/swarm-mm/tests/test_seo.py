"""SEO surface tests — landing, robots, sitemap, llms, seo.json."""

from __future__ import annotations

import os
import re

os.environ["SWARM_MM_DEV_OPEN"] = "1"
os.environ.pop("SML_API_KEY", None)

from fastapi.testclient import TestClient

from swarm_mm.api.app import app

client = TestClient(app)


def test_landing_has_seo_meta_and_jsonld():
    r = client.get("/landing")
    assert r.status_code == 200
    html = r.text
    assert "canonical" in html
    assert "www.scriptmasterlabs.com/swarm-market-making.html" in html
    assert "application/ld+json" in html
    assert "FAQPage" in html
    assert "SoftwareApplication" in html
    assert "HowTo" in html
    assert "swarm market making" in html.lower()
    assert "$19" in html or "19/mo" in html
    assert "Free" in html or "$0" in html
    # no onrender canonical
    assert not re.search(r'rel="canonical"[^>]+onrender', html)


def test_seo_aliases():
    for path in ("/swarm-market-making", "/swarm-market-making.html"):
        r = client.get(path)
        assert r.status_code == 200
        assert "Swarm Market Making" in r.text


def test_robots_sitemap_llms():
    robots = client.get("/robots.txt")
    assert robots.status_code == 200
    assert "Sitemap:" in robots.text
    assert "Allow: /landing" in robots.text

    sm = client.get("/sitemap.xml")
    assert sm.status_code == 200
    assert "swarm-market-making.html" in sm.text
    assert "www.scriptmasterlabs.com" in sm.text
    assert "onrender.com" not in sm.text

    llms = client.get("/llms.txt")
    assert llms.status_code == 200
    assert "Swarm Market Making" in llms.text
    assert "$19" in llms.text or "19/mo" in llms.text
    assert "0.001" in llms.text


def test_seo_json_card():
    r = client.get("/seo.json")
    assert r.status_code == 200
    d = r.json()
    assert d["canonical"].startswith("https://www.scriptmasterlabs.com/")
    assert d["www_only_gsc"] is True
    assert d["never_verify_onrender_dns"] is True
    assert d["free"]["price_usd"] == 0
    assert d["monthly_usd"]["signal"] == 19
    assert "swarm market making" in d["primary_keywords"]
