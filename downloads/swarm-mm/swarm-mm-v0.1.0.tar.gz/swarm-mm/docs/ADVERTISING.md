# Swarm MM Advertising — Beastmode Brief

## Message architecture (locked)

1. **Mechanism first** — coordination without custody
2. **Free portion** — Sim Swarm $0
3. **Prices** — $9 / $19 / $5K monthly + $0.001 agent calls
4. **Rails** — USDC Base, USDC Sol, RLUSD XRPL, USDG RH (USCG=USDG)
5. **CTA** — start free paper · or agent 402

## Do not lead with
- “AI trading bot”
- Pooled returns
- Guaranteed rebate
- Broker replacement

## Lead with
- Shared maker ladder from swarm intent
- You keep broker + capital
- Free track record path
- Crypto monthly + agent PPC

## Endpoints
- GET /v1/pricing
- GET /v1/ads/beastmode
- GET /landing
- GET /v1/ads/x
- File: AD_PACK_PASTE_READY.txt in downloads
